package com.company;

/**
 * Created by lysogordima on 12.05.16.
 */
public interface IExecutor {
    void execute();
}


